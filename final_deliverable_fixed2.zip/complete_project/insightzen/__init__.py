"""Django project package for InsightZen.

This file intentionally left blank. It marks the directory as a Python
package and can be used to perform any project-level initialisation if
required in the future.
"""