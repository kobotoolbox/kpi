"""Command subpackage for InsightZen management commands.

This module registers the custom commands with Django so that they
become available via ``python manage.py <command>``.  See the individual
modules in this package for command specifics.
"""