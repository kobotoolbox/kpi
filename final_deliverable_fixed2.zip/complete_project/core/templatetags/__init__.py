"""Template tags package for the core app.

This file marks the directory as a Python package so that Django can
discover custom template tags defined herein.
"""